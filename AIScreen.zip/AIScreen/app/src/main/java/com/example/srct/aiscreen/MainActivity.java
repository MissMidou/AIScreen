package com.example.srct.aiscreen;

import android.Manifest;
import android.content.Intent;
//import android.support.v7.app.AppCompatActivity;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


public class MainActivity extends AppCompatActivity {
    private final String TAG = "AppCompatActivity";

    Rect r;
    TextView text = null;
    static boolean isBoomed = false;
    private static final int REQUEST_PERMISSION = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text = (TextView)findViewById(R.id.text);
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // If you do not have permission, request it
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_PHONE_STATE, Manifest.permission.ACCESS_FINE_LOCATION},
                    REQUEST_PERMISSION);
            Log.d(TAG, "request permission");

        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        text.setText("getSize  " + event.getSize() + "getPressure"+ event.getPressure());
        if(!isBoomed && event.getSize() > 0.05) {
            Intent intent = new Intent(MainActivity.this, BoomAnimActivity.class);
            intent.putExtra("boom_startx", (int)event.getX());
            intent.putExtra("boom_starty", (int)event.getY());
            startActivity(intent);
            isBoomed = true;
        }
        return super.onTouchEvent(event);
    }

    @Override
    protected void onResume() {
        super.onResume();
        isBoomed = false;
    }

    @Override
    protected void onPause() {
        super.onPause();

    }
}
